# pamac-updates
GNOME Shell Updates indicator for Pamac

## Credits
This is a rebranded and customized extension, original extension can be found here
https://github.com/RaphaelRochet/arch-update

Any credit at the original author Raphaël Rochet

Contributor [Matti Hyttinen](https://github.com/Chrysostomus)
